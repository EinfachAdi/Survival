package de.einfachadi.survival.Item;

import de.einfachadi.survival.util.ModTags;
import net.minecraft.item.ToolMaterial;

public class ModToolMaterials {
    public static final ToolMaterial NETHER_EMERALD = new ToolMaterial(ModTags.Blocks.INCORRECT_FOR_NETHER_EMERALD_TOOL, 1500, 17.0f,
            5.0f, 22, ModTags.Items.NETHER_EMERALD_REPAIR);
}
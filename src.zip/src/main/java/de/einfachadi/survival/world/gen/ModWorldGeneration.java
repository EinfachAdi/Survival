package de.einfachadi.survival.world.gen;

import de.einfachadi.survival.world.ModOrePlacement;

public class ModWorldGeneration {
    public static void generateModWorldGen() {
        ModOreGeneration.generateOres();
    }
}
package de.einfachadi.survival.component;

import de.einfachadi.survival.Survival;

public class ModDataComponentTypes {

    public static void registerDataComponentTypes() {
        Survival.LOGGER.info("Registering Data Component Types for "+ Survival.MOD_ID);
    }


}

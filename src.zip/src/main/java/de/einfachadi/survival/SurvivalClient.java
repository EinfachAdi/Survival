package de.einfachadi.survival;


import net.fabricmc.api.ClientModInitializer;

public class SurvivalClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        }
}
